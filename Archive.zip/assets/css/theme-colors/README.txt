






*************************************************
	
       	   MEDICAL GUIDE THEME COLOR SCHEME

*************************************************



You can choose one color scheme here.
After choosing your desired scheme please copy and paste file in root of css folder.

NOTE: Default color scheme css is already in css folder, you don't need to do anything for default scheme.